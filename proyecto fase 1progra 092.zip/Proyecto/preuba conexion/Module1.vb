﻿Imports System.Data.SqlClient
Imports System.Data.Sql
Module Module1
    Public conn As SqlConnection
    Public enunciado As SqlCommand
    Public respuesta As SqlDataReader
    Sub abrir()
        Try
            conn = New SqlConnection("Data Source=DESKTOP-MNPTPJG\SQLEXPRESS;Initial Catalog=USUARIO;Integrated Security=True")
            conn.Open()
            MsgBox("conectado")

        Catch ex As Exception
            MsgBox("no se puedo conectar" + ex.ToString)

        End Try
    End Sub

    Function usuarioRegistrado(ByVal nombreUsuario As String) As Boolean
        Dim resultado As Boolean = False
        Try
            enunciado = New SqlCommand("Select*from USUARIOS where USUARIO='" & nombreUsuario & " ' ", conn)
            respuesta = enunciado.ExecuteReader

            If respuesta.Read Then
                resultado = True

            End If
            respuesta.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
        Return resultado
    End Function
    Function contraseña(ByVal nombreUsuario As String) As String
        Dim resultado As String = ""
        Try
            enunciado = New SqlCommand("Select  CONTRASEÑA from   USUARIOS where USUARIO ='" & nombreUsuario & " ' ", conn)
            respuesta = enunciado.ExecuteReader

            If respuesta.Read Then
                resultado = respuesta.Item("CONTRASEÑA")

            End If
            respuesta.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
        Return resultado
    End Function
    Function consultartipousuario(ByVal nombreUsuario As String) As String
        Dim resultado As String
        Try
            enunciado = New SqlCommand("Select TIPO_USSR from USUARIOS where USUARIO='" & nombreUsuario & " ' ", conn)
            respuesta = enunciado.ExecuteReader

            If respuesta.Read Then
                resultado = respuesta.Item("TIPO_USSR")

            End If
            respuesta.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
        Return resultado
    End Function

    Function IMAGEN(ByVal nombreUsuario As String) As String
        Dim resultado As String
        Try
            enunciado = New SqlCommand("Select  IMAGEN  from   USUARIOS where  IMAGEN ='" & nombreUsuario & " ' ", conn)
            respuesta = enunciado.ExecuteReader

            If respuesta.Read Then
                resultado = respuesta.Item("IMAGEN")

            End If
            respuesta.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
        Return resultado
    End Function
End Module

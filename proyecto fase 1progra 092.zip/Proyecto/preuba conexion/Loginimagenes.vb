﻿Public Class Loginimagenes
    Private Sub P1_Click(sender As Object, e As EventArgs) Handles dos.Click
        Try
            Dim imagenes As String = IMAGEN(uno.Image.ToString)
            If imagenes.Equals(uno.Image) = True Then
                Doshboad.ShowDialog()
            Else
                MsgBox("seleccione la correcta ", MsgBoxStyle.Critical)

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim imagenes As Object = IMAGEN(uno.Image.ToString)
            If imagenes.Equals(uno.Image) = True Then
                Doshboad.ShowDialog()
            Else
                MsgBox("seleccione la correcta ", MsgBoxStyle.Critical)

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Loginimagenes_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
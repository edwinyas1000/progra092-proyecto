﻿Public Class fAdminitrador
    Private Sub Bgestionaredito_Click(sender As Object, e As EventArgs) Handles Bgestionaredito.Click
        gestionaredit.Show()
        Me.Hide()

    End Sub

    Private Sub Bgeslibros_Click(sender As Object, e As EventArgs) Handles Bgeslibros.Click
        Gestionarlibros.Show()
        Me.Hide()

    End Sub

    Private Sub reportes_Click(sender As Object, e As EventArgs) Handles reportes.Click
        Reporte.Show()
        Me.Hide()

    End Sub

    Private Sub Bcerrar_Click(sender As Object, e As EventArgs) Handles Bcerrar.Click
        Me.Close()

    End Sub

    Private Sub fAdminitrador_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
﻿Public Class Gestionarlibros
    Private Sub Gestionarlibros_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub regresar_Click(sender As Object, e As EventArgs) Handles regresar.Click
        fAdminitrador.Show()
        Me.Hide()

    End Sub
End Class
﻿Public Class Fregistrar
    Private Sub BRegresar_Click(sender As Object, e As EventArgs) Handles BRegresar.Click
        Login.Show()
        Me.Hide()

    End Sub

    Private Sub Fregistrar_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
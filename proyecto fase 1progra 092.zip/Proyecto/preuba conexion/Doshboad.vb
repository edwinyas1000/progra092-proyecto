﻿Public Class Doshboad
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Beditarperf.Click
        Fmiperfil.Show()
        Me.Hide()

    End Sub

    Private Sub Blibrospres_Click(sender As Object, e As EventArgs) Handles Blibrospres.Click
        Librospres.Show()
        Me.Hide()

    End Sub

    Private Sub Bprestarli_Click(sender As Object, e As EventArgs) Handles Bprestarli.Click
        Prestarlibros.Show()
        Me.Hide()

    End Sub

    Private Sub Bcerrar_Click(sender As Object, e As EventArgs) Handles Bcerrar.Click
        Me.Close()

    End Sub

    Private Sub Doshboad_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
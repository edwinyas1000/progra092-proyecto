﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fAdminitrador
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Bgestionaredito = New System.Windows.Forms.Button()
        Me.Bgeslibros = New System.Windows.Forms.Button()
        Me.reportes = New System.Windows.Forms.Button()
        Me.Bcerrar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Bgestionaredito
        '
        Me.Bgestionaredito.Location = New System.Drawing.Point(301, 50)
        Me.Bgestionaredito.Name = "Bgestionaredito"
        Me.Bgestionaredito.Size = New System.Drawing.Size(168, 38)
        Me.Bgestionaredito.TabIndex = 0
        Me.Bgestionaredito.Text = "Gestionar Editoriales"
        Me.Bgestionaredito.UseVisualStyleBackColor = True
        '
        'Bgeslibros
        '
        Me.Bgeslibros.Location = New System.Drawing.Point(301, 135)
        Me.Bgeslibros.Name = "Bgeslibros"
        Me.Bgeslibros.Size = New System.Drawing.Size(168, 43)
        Me.Bgeslibros.TabIndex = 1
        Me.Bgeslibros.Text = "Gestionar Libros"
        Me.Bgeslibros.UseVisualStyleBackColor = True
        '
        'reportes
        '
        Me.reportes.Location = New System.Drawing.Point(301, 216)
        Me.reportes.Name = "reportes"
        Me.reportes.Size = New System.Drawing.Size(168, 42)
        Me.reportes.TabIndex = 2
        Me.reportes.Text = "Reportes"
        Me.reportes.UseVisualStyleBackColor = True
        '
        'Bcerrar
        '
        Me.Bcerrar.Location = New System.Drawing.Point(591, 373)
        Me.Bcerrar.Name = "Bcerrar"
        Me.Bcerrar.Size = New System.Drawing.Size(150, 23)
        Me.Bcerrar.TabIndex = 3
        Me.Bcerrar.Text = "Cerrar Sesion"
        Me.Bcerrar.UseVisualStyleBackColor = True
        '
        'fAdminitrador
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Bcerrar)
        Me.Controls.Add(Me.reportes)
        Me.Controls.Add(Me.Bgeslibros)
        Me.Controls.Add(Me.Bgestionaredito)
        Me.Name = "fAdminitrador"
        Me.Text = "Adminstrador"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Bgestionaredito As Button
    Friend WithEvents Bgeslibros As Button
    Friend WithEvents reportes As Button
    Friend WithEvents Bcerrar As Button
End Class

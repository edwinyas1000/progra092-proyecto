﻿Public Class Librospres
    Private Sub Bregresar_Click(sender As Object, e As EventArgs) Handles Bregresar.Click
        Doshboad.Show()
        Me.Hide()

    End Sub
End Class
﻿Public Class Reporte
    Private Sub Bregresar_Click(sender As Object, e As EventArgs) Handles Bregresar.Click
        fAdminitrador.Show()
        Me.Hide()

    End Sub
End Class
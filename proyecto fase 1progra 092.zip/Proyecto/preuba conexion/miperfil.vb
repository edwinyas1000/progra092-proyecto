﻿Public Class Fmiperfil
    Private Sub Fmiperfil_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Bregresar_Click(sender As Object, e As EventArgs) Handles Bregresar.Click
        Doshboad.Show()
        Me.Hide()

    End Sub
End Class
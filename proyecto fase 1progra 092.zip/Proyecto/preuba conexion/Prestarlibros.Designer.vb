﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Prestarlibros
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Bbuscar = New System.Windows.Forms.Button()
        Me.Bregresar = New System.Windows.Forms.Button()
        Me.Bprestar = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(97, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Elige un   Libro de su interes"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(100, 117)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(633, 150)
        Me.DataGridView1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(97, 280)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(230, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Para prestar libro, haga click en el titulo de este"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(549, 35)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 3
        '
        'Bbuscar
        '
        Me.Bbuscar.Location = New System.Drawing.Point(692, 32)
        Me.Bbuscar.Name = "Bbuscar"
        Me.Bbuscar.Size = New System.Drawing.Size(75, 23)
        Me.Bbuscar.TabIndex = 4
        Me.Bbuscar.Text = "Buscar"
        Me.Bbuscar.UseVisualStyleBackColor = True
        '
        'Bregresar
        '
        Me.Bregresar.Location = New System.Drawing.Point(692, 370)
        Me.Bregresar.Name = "Bregresar"
        Me.Bregresar.Size = New System.Drawing.Size(75, 23)
        Me.Bregresar.TabIndex = 5
        Me.Bregresar.Text = "Regresar"
        Me.Bregresar.UseVisualStyleBackColor = True
        '
        'Bprestar
        '
        Me.Bprestar.Location = New System.Drawing.Point(227, 350)
        Me.Bprestar.Name = "Bprestar"
        Me.Bprestar.Size = New System.Drawing.Size(75, 23)
        Me.Bprestar.TabIndex = 6
        Me.Bprestar.Text = "Prestar"
        Me.Bprestar.UseVisualStyleBackColor = True
        '
        'Prestarlibros
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Bprestar)
        Me.Controls.Add(Me.Bregresar)
        Me.Controls.Add(Me.Bbuscar)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Prestarlibros"
        Me.Text = "Prestar Libros"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Bbuscar As Button
    Friend WithEvents Bregresar As Button
    Friend WithEvents Bprestar As Button
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Loginimagenes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.uno = New System.Windows.Forms.PictureBox()
        Me.cero = New System.Windows.Forms.PictureBox()
        Me.tres = New System.Windows.Forms.PictureBox()
        Me.dos = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.uno, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cero, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tres, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'uno
        '
        Me.uno.Image = Global.preuba_conexion.My.Resources.Resources._12_128773_hd_wallpaper_dragon_ball_pc_background
        Me.uno.Location = New System.Drawing.Point(44, 257)
        Me.uno.Name = "uno"
        Me.uno.Size = New System.Drawing.Size(183, 133)
        Me.uno.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.uno.TabIndex = 3
        Me.uno.TabStop = False
        '
        'cero
        '
        Me.cero.Image = Global.preuba_conexion.My.Resources.Resources.FB_IMG_15960925151170296
        Me.cero.Location = New System.Drawing.Point(273, 257)
        Me.cero.Name = "cero"
        Me.cero.Size = New System.Drawing.Size(179, 133)
        Me.cero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cero.TabIndex = 2
        Me.cero.TabStop = False
        '
        'tres
        '
        Me.tres.Image = Global.preuba_conexion.My.Resources.Resources.kj
        Me.tres.Location = New System.Drawing.Point(273, 26)
        Me.tres.Name = "tres"
        Me.tres.Size = New System.Drawing.Size(179, 133)
        Me.tres.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tres.TabIndex = 1
        Me.tres.TabStop = False
        '
        'dos
        '
        Me.dos.Cursor = System.Windows.Forms.Cursors.Hand
        Me.dos.Image = Global.preuba_conexion.My.Resources.Resources._26879
        Me.dos.Location = New System.Drawing.Point(35, 26)
        Me.dos.Name = "dos"
        Me.dos.Size = New System.Drawing.Size(183, 133)
        Me.dos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.dos.TabIndex = 0
        Me.dos.TabStop = False
        Me.dos.WaitOnLoad = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(620, 72)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Aceptar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Loginimagenes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.uno)
        Me.Controls.Add(Me.cero)
        Me.Controls.Add(Me.tres)
        Me.Controls.Add(Me.dos)
        Me.Name = "Loginimagenes"
        Me.Text = "Iniciar Sesion"
        CType(Me.uno, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cero, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tres, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cero As PictureBox
    Friend WithEvents uno As PictureBox
    Friend WithEvents Button1 As Button
    Public WithEvents dos As PictureBox
    Public WithEvents tres As PictureBox
End Class

﻿
Public Class Login

    Private Sub Blogin_Click(sender As Object, e As EventArgs) Handles Blogin.Click
        Try
            If usuarioRegistrado(Tnombre.Text) = True Then
                Dim contra As String = contraseña(Tnombre.Text)
                If contra.Equals(Tcontraseña.Text) = True Then
                    Me.Hide()
                    If consultartipousuario(Tnombre.Text) = "Administrador" Then
                        fAdminitrador.ShowDialog()
                    ElseIf consultartipousuario(Tnombre.Text) = "Cliente" Then
                        Doshboad.ShowDialog()


                    End If
                Else
                    MsgBox("contraseña invalida", MsgBoxStyle.Critical)
                End If
            Else
                MsgBox("el usuario:" + Tnombre.Text + "no se encuentra registrado")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Bregistrarse_Click(sender As Object, e As EventArgs) Handles Bregistrarse.Click
        Fregistrar.Show()
        Me.Hide()
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        abrir()

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            Tcontraseña.PasswordChar = " "
        ElseIf CheckBox1.Checked = False Then
            Tcontraseña.PasswordChar = " * "
        End If
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub
End Class